use clap::{Parser, Subcommand};
use si_net::parse_invite;
use si_silsila::{kinship_check, Edge, EdgeType, Gender, Person};
use si_tokenomics::{genesis_amount, FUNDS, TOTAL_SUPPLY, TOTAL_UNITS};
use si_wallet::new_wallet;

#[derive(Parser)]
#[command(name = "si", about = "si CLI — wallet, silsila, token, referral")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Create a new wallet (prints address; seed to stdout once)
    Wallet {
        #[command(subcommand)]
        action: WalletCmd,
    },
    Silsila {
        #[command(subcommand)]
        action: SilsilaCmd,
    },
    Token {
        #[command(subcommand)]
        action: TokenCmd,
    },
    Ref {
        #[command(subcommand)]
        action: RefCmd,
    },
}

#[derive(Subcommand)]
enum WalletCmd {
    New,
}

#[derive(Subcommand)]
enum SilsilaCmd {
    Check {
        #[arg(long)]
        a: String,
        #[arg(long)]
        b: String,
    },
}

#[derive(Subcommand)]
enum TokenCmd {
    GenesisInfo,
}

#[derive(Subcommand)]
enum RefCmd {
    Apply { code: String },
}

fn main() {
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::Wallet { action: WalletCmd::New } => match new_wallet() {
            Ok((mnemonic, kp)) => {
                println!("address {}", kp.address);
                println!("mnemonic {mnemonic}");
                println!("write the words on paper. this is the only print.");
            }
            Err(e) => {
                eprintln!("{e}");
                std::process::exit(1);
            }
        },
        Cmd::Token { action: TokenCmd::GenesisInfo } => {
            println!("SILAL total {TOTAL_SUPPLY}");
            println!("units {TOTAL_UNITS}");
            println!("sum_funds {}", genesis_amount());
            for f in FUNDS {
                println!("{} {} {}bps", f.id, f.amount, f.bps);
            }
        }
        Cmd::Silsila {
            action: SilsilaCmd::Check { a, b },
        } => {
            // Tiny built-in demo graph: gf -> f,u -> a,c
            let people = vec![
                person("gf", Gender::Male),
                person("f", Gender::Male),
                person("u", Gender::Male),
                person("a", Gender::Male),
                person("c", Gender::Male),
            ];
            let edges = vec![
                edge("gf", "f"),
                edge("gf", "u"),
                edge("f", "a"),
                edge("u", "c"),
            ];
            let r = kinship_check(&people, &edges, &a, &b);
            println!("{:?} — {} (state_ban={})", r.kind, r.reason, r.is_state_ban);
        }
        Cmd::Ref {
            action: RefCmd::Apply { code },
        } => match parse_invite(&code) {
            Ok(inv) => println!("{inv:?} — depth 1, paid only from the community fund"),
            Err(_) => {
                eprintln!("bad code");
                std::process::exit(1);
            }
        },
    }
}

fn person(id: &str, gender: Gender) -> Person {
    Person {
        id: id.into(),
        name: id.into(),
        gender,
        living: true,
        consent_to_publish: true,
    }
}

fn edge(from: &str, to: &str) -> Edge {
    Edge {
        kind: EdgeType::Parent,
        from: from.into(),
        to: to.into(),
    }
}
