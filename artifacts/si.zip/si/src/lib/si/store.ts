import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Locale } from "./i18n";
import { isLocale } from "./i18n";
import {
  FAMILY_AIRDROP_TOKENS,
  tokensToUnits,
} from "./tokenomics";
import {
  generateMnemonic12,
  mnemonicIsValid,
  newWalletFromMnemonic,
  sealVault,
  unsealVault,
  isSiAddress,
  txIdFor,
  protocolAddress,
  type SealedVault,
  type VaultPlain,
} from "./crypto";
import {
  genesisLedger,
  applyTransfer,
  fundAddress,
  getBalance,
  type Ledger,
  type LedgerTx,
} from "./ledger";
import {
  type Person,
  type KinEdge,
  type EdgeType,
  type Gender,
  canAddEdge,
  sampleLineage,
  toGedcom,
  kinshipCheck,
  type KinshipResult,
} from "./silsila";
import { applyReferralPayout, codeFromAddress, parseInvite, type ReferralState } from "./referral";
import { EVENTS } from "./events-data";
import { playSound, setSoundsEnabled } from "./sounds";

export type Theme = "dark" | "light";
export type DocKind = "nikkah" | "diploma" | "proxy" | "other";

export interface ArchiveDoc {
  id: string;
  title: string;
  kind: DocKind;
  sha256: string;
  blake3?: string;
  bytes: number;
  addedAt: number;
  note?: string;
}

export interface CircleMember {
  id: string;
  name: string;
  role: "member" | "elder";
  joinedAt: number;
}

export interface SiProfile {
  name: string;
  taip?: string;
  country?: string;
  hiddenProfile: boolean;
  familyContact?: string;
  birthYear?: number;
}

export interface SiPublicState {
  locale: Locale;
  theme: Theme;
  sounds: boolean;
  onboardingComplete: boolean;
  profile: SiProfile | null;
  address: string | null;
  referral: ReferralState | null;
  ledger: Ledger;
  people: Person[];
  edges: KinEdge[];
  documents: ArchiveDoc[];
  rsvps: string[];
  circle: CircleMember[];
  circleCode: string;
  blocked: string[];
  familyAirdropPaid: boolean;
  sampleSeeded: boolean;
}

interface Session {
  unlocked: boolean;
  mnemonic: string | null;
  secretKeyHex: string | null;
  publicKeyHex: string | null;
}

interface SiStore extends SiPublicState {
  vault: SealedVault | null;
  session: Session;
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  setLocale: (l: Locale) => void;
  setTheme: (t: Theme) => void;
  setSounds: (v: boolean) => void;
  createWallet: (password: string, profile: SiProfile) => Promise<VaultPlain>;
  importWallet: (mnemonic: string, password: string, profile: SiProfile) => Promise<VaultPlain>;
  unlock: (password: string) => Promise<boolean>;
  lock: () => void;
  updateProfile: (p: Partial<SiProfile>) => void;
  transfer: (to: string, amount: bigint, memo: string) => { ok: boolean; error?: string };
  addPerson: (p: Omit<Person, "id" | "createdAt">) => string;
  updatePerson: (id: string, p: Partial<Person>) => void;
  removePerson: (id: string) => void;
  link: (type: EdgeType, from: string, to: string) => { ok: boolean; errorKey?: string };
  kinship: (a: string, b: string) => KinshipResult | null;
  seedSample: () => void;
  addDocument: (doc: Omit<ArchiveDoc, "id" | "addedAt">) => void;
  removeDocument: (id: string) => void;
  rsvp: (eventId: string) => void;
  applyRef: (raw: string) => { ok: boolean; error?: string };
  addCircleMember: (name: string, role: "member" | "elder") => void;
  setCircleRole: (id: string, role: "member" | "elder") => void;
  removeCircleMember: (id: string) => void;
  blockContact: (label: string) => void;
  unblockContact: (label: string) => void;
  exportGedcom: () => string;
  exportAll: () => string;
  completeOnboarding: () => void;
  wipe: () => void;
  maybeQualify: () => void;
}

const emptySession = (): Session => ({
  unlocked: false,
  mnemonic: null,
  secretKeyHex: null,
  publicKeyHex: null,
});

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}

function newCircleCode(): string {
  return `C-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

const initialPublic = (): SiPublicState => ({
  locale: "ce",
  theme: "dark",
  sounds: true,
  onboardingComplete: false,
  profile: null,
  address: null,
  referral: null,
  ledger: genesisLedger(),
  people: [],
  edges: [],
  documents: [],
  rsvps: [],
  circle: [],
  circleCode: newCircleCode(),
  blocked: [],
  familyAirdropPaid: false,
  sampleSeeded: false,
});

function persistable(s: SiStore) {
  return {
    locale: s.locale,
    theme: s.theme,
    sounds: s.sounds,
    onboardingComplete: s.onboardingComplete,
    profile: s.profile,
    address: s.address,
    referral: s.referral,
    ledger: s.ledger,
    people: s.people,
    edges: s.edges,
    documents: s.documents,
    rsvps: s.rsvps,
    circle: s.circle,
    circleCode: s.circleCode,
    blocked: s.blocked,
    familyAirdropPaid: s.familyAirdropPaid,
    sampleSeeded: s.sampleSeeded,
    vault: s.vault,
  };
}

export const useSi = create<SiStore>()(
  persist(
    (set, get) => ({
      ...initialPublic(),
      vault: null,
      session: emptySession(),
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      setLocale: (locale) => {
        if (!isLocale(locale)) return;
        set({ locale });
      },
      setTheme: (theme) => {
        set({ theme });
        if (typeof document !== "undefined") {
          document.documentElement.dataset.theme = theme;
        }
      },
      setSounds: (sounds) => {
        setSoundsEnabled(sounds);
        set({ sounds });
      },
      createWallet: async (password, profile) => {
        const mnemonic = generateMnemonic12();
        const plain = newWalletFromMnemonic(mnemonic);
        const vault = await sealVault(plain, password);
        const self: Person = {
          id: "self",
          name: profile.name,
          gender: "unknown",
          living: true,
          consentToPublish: true,
          isSelf: true,
          isMinor: isMinor(profile.birthYear),
          birthYear: profile.birthYear,
          taip: profile.taip,
          walletAddress: isMinor(profile.birthYear) ? undefined : plain.address,
          createdAt: Date.now(),
        };
        const referral: ReferralState = {
          code: codeFromAddress(plain.address),
          qualified: false,
          payoutTxIds: [],
        };
        set({
          vault,
          onboardingComplete: false,
          profile,
          address: plain.address,
          referral,
          people: [self],
          session: {
            unlocked: true,
            mnemonic: plain.mnemonic,
            secretKeyHex: plain.secretKeyHex,
            publicKeyHex: plain.publicKeyHex,
          },
        });
        return plain;
      },
      importWallet: async (mnemonic, password, profile) => {
        if (!mnemonicIsValid(mnemonic)) throw new Error("mnemonic");
        const plain = newWalletFromMnemonic(mnemonic);
        const vault = await sealVault(plain, password);
        const self: Person = {
          id: "self",
          name: profile.name,
          gender: "unknown",
          living: true,
          consentToPublish: true,
          isSelf: true,
          isMinor: isMinor(profile.birthYear),
          birthYear: profile.birthYear,
          taip: profile.taip,
          walletAddress: isMinor(profile.birthYear) ? undefined : plain.address,
          createdAt: Date.now(),
        };
        set({
          vault,
          onboardingComplete: false,
          profile,
          address: plain.address,
          referral: { code: codeFromAddress(plain.address), qualified: false, payoutTxIds: [] },
          people: [self],
          session: {
            unlocked: true,
            mnemonic: plain.mnemonic,
            secretKeyHex: plain.secretKeyHex,
            publicKeyHex: plain.publicKeyHex,
          },
        });
        return plain;
      },
      unlock: async (password) => {
        const { vault } = get();
        if (!vault) return false;
        try {
          const plain = await unsealVault(vault, password);
          set({
            session: {
              unlocked: true,
              mnemonic: plain.mnemonic,
              secretKeyHex: plain.secretKeyHex,
              publicKeyHex: plain.publicKeyHex,
            },
            address: plain.address,
          });
          return true;
        } catch {
          return false;
        }
      },
      lock: () => set({ session: emptySession() }),
      updateProfile: (p) => {
        const cur = get().profile;
        if (!cur) return;
        const next = { ...cur, ...p };
        set({
          profile: next,
          people: get().people.map((person) =>
            person.isSelf
              ? {
                  ...person,
                  name: next.name,
                  taip: next.taip,
                  hidden: next.hiddenProfile,
                  birthYear: next.birthYear,
                  isMinor: isMinor(next.birthYear),
                }
              : person,
          ),
        });
      },
      transfer: (to, amount, memo) => {
        const s = get();
        if (!s.address) return { ok: false, error: "wallet" };
        if (s.people.find((p) => p.isSelf)?.isMinor) return { ok: false, error: "minor" };
        if (!isSiAddress(to) && !to.startsWith("si1")) return { ok: false, error: "addr" };
        const r = applyTransfer(s.ledger, {
          from: s.address,
          to,
          amount,
          memo,
          kind: "transfer",
          txId: txIdFor(`${s.address}|${to}|${amount}|${memo}|${Date.now()}`),
        });
        if (!r.ok) return { ok: false, error: r.error };
        set({ ledger: r.ledger });
        void playSound("tx_sent");
        return { ok: true };
      },
      addPerson: (p) => {
        const id = uid("p");
        const person: Person = { ...p, id, createdAt: Date.now() };
        set({ people: [...get().people, person] });
        get().maybeQualify();
        return id;
      },
      updatePerson: (id, p) => {
        if (id === "self" && p.isSelf === false) return;
        set({
          people: get().people.map((person) => (person.id === id ? { ...person, ...p, id: person.id, isSelf: person.isSelf } : person)),
        });
      },
      removePerson: (id) => {
        if (id === "self") return;
        const s = get();
        set({
          people: s.people.filter((p) => p.id !== id),
          edges: s.edges.filter((e) => e.from !== id && e.to !== id),
        });
      },
      link: (type, from, to) => {
        const s = get();
        const r = canAddEdge(s.people, s.edges, type, from, to);
        if (!r.ok) {
          void playSound("ui_warn");
          return { ok: false, errorKey: r.errorKey };
        }
        const edge: KinEdge = { ...r.edge, id: uid("e"), createdAt: Date.now() };
        set({ edges: [...s.edges, edge] });
        get().maybeQualify();
        void playSound("ui_success");
        return { ok: true };
      },
      kinship: (a, b) => {
        const s = get();
        if (!s.people.some((p) => p.id === a) || !s.people.some((p) => p.id === b)) return null;
        return kinshipCheck(s.people, s.edges, a, b);
      },
      seedSample: () => {
        const s = get();
        if (s.sampleSeeded) return;
        const self = s.people.find((p) => p.isSelf);
        if (!self) return;
        const sample = sampleLineage(self.id, self.name);
        set({
          people: [...s.people, ...sample.people],
          edges: [...s.edges, ...sample.edges],
          sampleSeeded: true,
        });
        get().maybeQualify();
      },
      addDocument: (doc) => {
        const item: ArchiveDoc = { ...doc, id: uid("d"), addedAt: Date.now() };
        set({ documents: [item, ...get().documents] });
        get().maybeQualify();
        void playSound("ui_success");
      },
      removeDocument: (id) => set({ documents: get().documents.filter((d) => d.id !== id) }),
      rsvp: (eventId) => {
        const s = get();
        if (s.rsvps.includes(eventId)) return;
        if (!EVENTS.some((e) => e.id === eventId)) return;
        set({ rsvps: [...s.rsvps, eventId] });
        get().maybeQualify();
        void playSound("invite_accepted");
      },
      applyRef: (raw) => {
        const s = get();
        if (!s.referral || !s.address) return { ok: false, error: "wallet" };
        if (s.referral.referredBy) return { ok: false, error: "already" };
        const parsed = parseInvite(raw);
        if (!parsed || parsed.kind !== "ref") return { ok: false, error: "bad" };
        if (parsed.code === s.referral.code) return { ok: false, error: "self" };
        set({
          referral: {
            ...s.referral,
            referredBy: parsed.code,
            appliedAt: Date.now(),
          },
        });
        get().maybeQualify();
        void playSound("ui_success");
        return { ok: true };
      },
      addCircleMember: (name, role) => {
        const m: CircleMember = { id: uid("c"), name, role, joinedAt: Date.now() };
        set({ circle: [...get().circle, m] });
        void playSound("invite_accepted");
      },
      setCircleRole: (id, role) => {
        set({ circle: get().circle.map((m) => (m.id === id ? { ...m, role } : m)) });
      },
      removeCircleMember: (id) => set({ circle: get().circle.filter((m) => m.id !== id) }),
      blockContact: (label) => {
        const t = label.trim();
        if (!t) return;
        if (get().blocked.includes(t)) return;
        set({ blocked: [...get().blocked, t] });
      },
      unblockContact: (label) => set({ blocked: get().blocked.filter((b) => b !== label) }),
      exportGedcom: () => toGedcom(get().people, get().edges),
      exportAll: () =>
        JSON.stringify(
          {
            exportedAt: new Date().toISOString(),
            product: "si",
            ...persistable(get() as SiStore),
            vault: undefined,
            mnemonic: undefined,
          },
          null,
          2,
        ),
      completeOnboarding: () => set({ onboardingComplete: true }),
      wipe: () => {
        set({
          ...initialPublic(),
          vault: null,
          session: emptySession(),
          hydrated: true,
          locale: get().locale,
          theme: get().theme,
        });
      },
      maybeQualify: () => {
        const s = get();
        if (!s.address || !s.referral) return;
        let ledger = s.ledger;
        let referral = s.referral;
        let familyAirdropPaid = s.familyAirdropPaid;

        const parentCount = s.edges.filter(
          (e) => (e.type === "parent" || e.type === "adoptive") && e.to === "self",
        ).length;
        if (!familyAirdropPaid && parentCount >= 2 && !s.people.find((p) => p.isSelf)?.isMinor) {
          const r = applyTransfer(ledger, {
            from: fundAddress("genesisAirdrop"),
            to: s.address,
            amount: tokensToUnits(FAMILY_AIRDROP_TOKENS),
            memo: "verified-family-airdrop",
            kind: "airdrop",
            txId: `airdrop:family:${s.address}`,
          });
          if (r.ok) {
            ledger = r.ledger;
            familyAirdropPaid = true;
          }
        }

        const sevenDays = Date.now() - (s.people.find((p) => p.isSelf)?.createdAt ?? Date.now()) > 7 * 86400000;
        const qualifies = s.documents.length > 0 || s.rsvps.length > 0 || sevenDays;
        if (qualifies && referral.referredBy && !referral.qualified) {
          const referrer = protocolAddress(`refholder:${referral.referredBy}`);
          const r = applyReferralPayout(ledger, {
            referrer,
            referee: s.address,
          });
          if (r.ok) {
            ledger = r.ledger;
            referral = { ...referral, qualified: true, qualifiedAt: Date.now() };
          }
        }

        if (ledger !== s.ledger || referral !== s.referral || familyAirdropPaid !== s.familyAirdropPaid) {
          set({ ledger, referral, familyAirdropPaid });
        }
      },
    }),
    {
      name: "si.v1",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => persistable(s as SiStore),
      skipHydration: true,
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<SiPublicState>;
        const locale = isLocale(p.locale) ? p.locale : current.locale;
        return { ...current, ...p, locale };
      },
    },
  ),
);

function isMinor(birthYear?: number): boolean {
  if (!birthYear) return false;
  return new Date().getFullYear() - birthYear < 18;
}

export function selfPerson(s: SiPublicState): Person | undefined {
  return s.people.find((p) => p.isSelf);
}

export function myBalance(s: SiPublicState): bigint {
  if (!s.address) return 0n;
  return getBalance(s.ledger, s.address);
}

export function myTxs(s: SiPublicState): LedgerTx[] {
  if (!s.address) return [];
  return s.ledger.txs.filter((t) => t.to === s.address || t.from === s.address);
}

export { getBalance, fundAddress };
