import { useState } from "react";
import { useSi, type DocKind } from "@/lib/si/store";
import { useT } from "@/lib/si/use-t";
import { sha256Hex, blake3Hex } from "@/lib/si/crypto";
import { playSound } from "@/lib/si/sounds";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const kinds: DocKind[] = ["nikkah", "diploma", "proxy", "other"];

export function ArchiveScreen() {
  const t = useT();
  const docs = useSi((s) => s.documents);
  const addDocument = useSi((s) => s.addDocument);
  const removeDocument = useSi((s) => s.removeDocument);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState<DocKind>("nikkah");
  const [busy, setBusy] = useState(false);
  const [hash, setHash] = useState<{ sha: string; blake: string; bytes: number } | null>(null);

  async function onFile(f: File | undefined) {
    if (!f) return;
    const buf = new Uint8Array(await f.arrayBuffer());
    setHash({ sha: sha256Hex(buf), blake: blake3Hex(buf), bytes: buf.length });
    if (!title) setTitle(f.name);
  }

  function save() {
    if (!hash || !title.trim()) return;
    setBusy(true);
    addDocument({
      title: title.trim(),
      kind,
      sha256: hash.sha,
      blake3: hash.blake,
      bytes: hash.bytes,
    });
    setBusy(false);
    setOpen(false);
    setTitle("");
    setHash(null);
  }

  const kindLabel: Record<DocKind, string> = {
    nikkah: t("archive.nikkah"),
    diploma: t("archive.diploma"),
    proxy: t("archive.proxy"),
    other: t("archive.other"),
  };

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-wool">{t("archive.title")}</p>
          <h1 className="font-display text-3xl">{t("nav.archive")}</h1>
        </div>
        <Button size="sm" onClick={() => setOpen(true)}>
          {t("archive.add")}
        </Button>
      </div>
      <p className="text-sm text-muted-foreground">{t("archive.stored")}</p>
      {docs.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border px-4 py-10 text-center text-muted-foreground">
          {t("archive.empty")}
        </p>
      ) : (
        <ul className="space-y-3">
          {docs.map((d) => (
            <li key={d.id} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="font-display text-lg">{d.title}</div>
                <Badge>{kindLabel[d.kind]}</Badge>
              </div>
              <p className="mt-2 break-all font-mono text-xs text-muted-foreground">
                {t("archive.hash")} SHA-256 {d.sha256}
              </p>
              {d.blake3 && (
                <p className="break-all font-mono text-xs text-muted-foreground">BLAKE3 {d.blake3}</p>
              )}
              <p className="mt-1 text-xs text-muted-foreground">
                {t("archive.size")} {(d.bytes / 1024).toFixed(1)} KB
              </p>
              <div className="mt-3 flex gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    void navigator.clipboard.writeText(d.sha256);
                    void playSound("ui_tap");
                  }}
                >
                  {t("archive.copyHash")}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => removeDocument(d.id)}>
                  {t("common.remove")}
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("archive.add")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Label>{t("archive.titleField")}</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
            <Label>{t("archive.kind")}</Label>
            <div className="grid grid-cols-2 gap-2">
              {kinds.map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setKind(k)}
                  className={cn(
                    "h-10 rounded-lg border text-sm",
                    kind === k ? "border-gold" : "border-border",
                  )}
                >
                  {kindLabel[k]}
                </button>
              ))}
            </div>
            <Label>{t("archive.file")}</Label>
            <input
              type="file"
              className="block w-full text-sm"
              onChange={(e) => void onFile(e.target.files?.[0])}
            />
            {hash && (
              <p className="break-all font-mono text-[11px] text-muted-foreground">
                SHA-256 {hash.sha}
              </p>
            )}
            <Button className="w-full" disabled={!hash || busy} onClick={save}>
              {t("common.save")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
