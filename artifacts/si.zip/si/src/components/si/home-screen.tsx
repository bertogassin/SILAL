import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Copy, GitFork, Calendar, Users } from "lucide-react";
import { formatUnits } from "@/lib/si/tokenomics";
import { useSi, getBalance } from "@/lib/si/store";
import { useT } from "@/lib/si/use-t";
import { locText, localeTag } from "@/lib/si/i18n";
import { EVENTS } from "@/lib/si/events-data";
import { playSound } from "@/lib/si/sounds";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TreeView } from "./tree-view";

export function HomeScreen() {
  const t = useT();
  const locale = useSi((s) => s.locale);
  const profile = useSi((s) => s.profile);
  const address = useSi((s) => s.address);
  const referral = useSi((s) => s.referral);
  const people = useSi((s) => s.people);
  const rsvps = useSi((s) => s.rsvps);
  const circle = useSi((s) => s.circle);
  const ledger = useSi((s) => s.ledger);
  const balance = address ? getBalance(ledger, address) : 0n;

  const nextEvent = EVENTS.filter((e) => new Date(e.at).getTime() >= Date.now() - 86400000).sort(
    (a, b) => +new Date(a.at) - +new Date(b.at),
  )[0];

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <p className="text-sm text-wool">{t("home.greeting")}</p>
        <h1 className="font-display text-3xl tracking-tight md:text-4xl">{profile?.name ?? "si"}</h1>
        {profile?.taip && <p className="mt-1 text-sm text-muted-foreground">{profile.taip}</p>}
      </div>

      <Card className="overflow-hidden">
        <CardContent className="p-5">
          <p className="text-xs uppercase tracking-[0.18em] text-wool">{t("home.balance")}</p>
          <p className="mt-2 font-display text-4xl tabular tracking-tight">
            {formatUnits(balance)}
            <span className="ml-2 text-base text-muted-foreground">SILAL</span>
          </p>
          <div className="mt-4 flex items-center gap-2">
            <code className="truncate text-xs text-muted-foreground">{address}</code>
            <button
              type="button"
              className="size-11 shrink-0 rounded-lg text-gold"
              aria-label={t("common.copy")}
              onClick={() => {
                if (address) void navigator.clipboard.writeText(address);
                void playSound("ui_tap");
              }}
            >
              <Copy className="mx-auto size-4" />
            </button>
          </div>
          <div className="mt-3 flex gap-2">
            <Button asChild size="sm" variant="outline">
              <Link to="/wallet">{t("wallet.send")}</Link>
            </Button>
            <Button asChild size="sm" variant="secondary">
              <Link to="/wallet">{t("wallet.receive")}</Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-sm uppercase tracking-[0.16em] text-wool">
            <GitFork className="size-4" /> {t("nav.tree")}
          </h2>
          <Link to="/silsila" className="text-sm text-gold">
            {t("common.more")}
          </Link>
        </div>
        {people.length <= 1 ? (
          <Link
            to="/silsila"
            className="flex items-center justify-between rounded-2xl border border-dashed border-border px-4 py-5"
          >
            <span>{t("home.emptyTree")}</span>
            <ArrowUpRight className="size-4 text-gold" />
          </Link>
        ) : (
          <TreeView />
        )}
      </section>

      {nextEvent && (
        <section>
          <h2 className="mb-3 flex items-center gap-2 text-sm uppercase tracking-[0.16em] text-wool">
            <Calendar className="size-4" /> {t("home.next")}
          </h2>
          <Link to="/events" className="block rounded-2xl border border-border bg-card p-4">
            <div className="font-display text-lg">{locText(locale, nextEvent.title)}</div>
            <div className="mt-1 text-sm text-muted-foreground">
              {locText(locale, nextEvent.place)} · {new Date(nextEvent.at).toLocaleString(localeTag(locale))}
            </div>
            {rsvps.includes(nextEvent.id) && (
              <div className="mt-2 text-xs text-gold">{t("events.rsvped")}</div>
            )}
          </Link>
        </section>
      )}

      <section className="grid grid-cols-2 gap-3">
        <Link to="/circle" className="rounded-2xl border border-border bg-card p-4">
          <Users className="mb-2 size-4 text-wool" />
          <div className="font-display">{t("home.circle")}</div>
          <div className="text-sm text-muted-foreground">{circle.length}</div>
        </Link>
        <Link to="/referrals" className="rounded-2xl border border-border bg-card p-4">
          <div className="text-xs uppercase tracking-[0.16em] text-wool">{t("home.ref")}</div>
          <div className="mt-2 font-mono text-sm">{referral?.code}</div>
        </Link>
      </section>
    </div>
  );
}
