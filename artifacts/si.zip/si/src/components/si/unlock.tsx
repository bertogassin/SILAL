import { useState } from "react";
import { useSi } from "@/lib/si/store";
import { useT } from "@/lib/si/use-t";
import { playSound } from "@/lib/si/sounds";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SiMark } from "./mark";

export function UnlockScreen() {
  const t = useT();
  const unlock = useSi((s) => s.unlock);
  const wipe = useSi((s) => s.wipe);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(false);
    const ok = await unlock(pw);
    setBusy(false);
    if (!ok) {
      setErr(true);
      void playSound("ui_warn");
    } else {
      void playSound("ui_success");
    }
  }

  return (
    <div className="relative flex min-h-dvh justify-center bg-background px-5 pt-[max(3rem,env(safe-area-inset-top))] text-foreground">
      <div className="si-grain absolute inset-0" />
      <div className="si-ridge pointer-events-none absolute inset-x-0 bottom-0 h-36" />
      <form onSubmit={onSubmit} className="relative mx-auto flex w-full max-w-sm flex-1 flex-col">
        <SiMark className="mb-4 size-12" />
        <h1 className="font-display text-3xl">{t("unlock.title")}</h1>
        <p className="mt-2 mb-6 text-sm text-muted-foreground">{t("unlock.body")}</p>
        <Label htmlFor="unlock-pw">{t("on.password")}</Label>
        <Input
          id="unlock-pw"
          className="mt-2"
          type="password"
          autoComplete="current-password"
          value={pw}
          onChange={(e) => setPw(e.target.value)}
        />
        {err && <p className="mt-2 text-sm text-garnet">{t("unlock.bad")}</p>}
        <Button className="mt-6" type="submit" disabled={busy || !pw}>
          {busy ? t("on.sealing") : t("wallet.unlock")}
        </Button>
        <button
          type="button"
          className="mt-auto pb-8 text-center text-sm text-muted-foreground"
          onClick={() => {
            if (confirm(t("settings.deleteHint"))) wipe();
          }}
        >
          {t("settings.delete")}
        </button>
      </form>
    </div>
  );
}
