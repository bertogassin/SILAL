import { useState } from "react";
import { useSi } from "@/lib/si/store";
import { useT } from "@/lib/si/use-t";
import { locText, localeTag } from "@/lib/si/i18n";
import { EVENTS, type CommunityEvent } from "@/lib/si/events-data";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { playSound } from "@/lib/si/sounds";

function icsFor(e: CommunityEvent, title: string, place: string, note: string): string {
  const start = new Date(e.at);
  const end = new Date(start.getTime() + 2 * 60 * 60 * 1000);
  const stamp = (d: Date) =>
    d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const esc = (s: string) => s.replace(/[,;\\]/g, "\\$&").replace(/\n/g, "\\n");
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//si//events//EN",
    "BEGIN:VEVENT",
    `UID:${e.id}@si`,
    `DTSTAMP:${stamp(new Date())}`,
    `DTSTART:${stamp(start)}`,
    `DTEND:${stamp(end)}`,
    `SUMMARY:${esc(title)}`,
    `LOCATION:${esc(place)}`,
    `DESCRIPTION:${esc(note)}`,
    "END:VEVENT",
    "END:VCALENDAR",
    "",
  ].join("\r\n");
}

export function EventsScreen() {
  const t = useT();
  const locale = useSi((s) => s.locale);
  const rsvps = useSi((s) => s.rsvps);
  const rsvp = useSi((s) => s.rsvp);
  const hidden = useSi((s) => s.profile?.hiddenProfile);
  const [onlyGoing, setOnlyGoing] = useState(false);
  const list = onlyGoing ? EVENTS.filter((e) => rsvps.includes(e.id)) : EVENTS;

  function downloadIcs(e: CommunityEvent) {
    const blob = new Blob(
      [icsFor(e, locText(locale, e.title), locText(locale, e.place), locText(locale, e.note))],
      { type: "text/calendar" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${e.id}.ics`;
    a.click();
    URL.revokeObjectURL(url);
    void playSound("ui_tap");
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.18em] text-wool">{t("events.title")}</p>
        <h1 className="font-display text-3xl">{t("nav.events")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">{t("events.mapHint")}</p>
      </div>

      <div className="relative overflow-hidden rounded-2xl border border-border bg-card">
        <div className="si-ridge absolute inset-0 opacity-80" />
        <div className="relative aspect-[16/10]">
          {EVENTS.map((e) => (
            <span
              key={e.id}
              className={cn(
                "absolute size-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border border-gold",
                rsvps.includes(e.id) ? "bg-gold" : "bg-wool/70",
              )}
              style={{ left: `${e.x}%`, top: `${e.y}%` }}
              title={e.city}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setOnlyGoing(false)}
          className={cn("h-11 rounded-xl border text-sm", !onlyGoing ? "border-gold bg-card" : "border-border")}
        >
          {t("events.allFilter")}
        </button>
        <button
          type="button"
          onClick={() => setOnlyGoing(true)}
          className={cn("h-11 rounded-xl border text-sm", onlyGoing ? "border-gold bg-card" : "border-border")}
        >
          {t("events.goingFilter")}
        </button>
      </div>

      <ul className="space-y-3">
        {list.map((e) => {
          const going = rsvps.includes(e.id);
          return (
            <li key={e.id} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-display text-lg">{locText(locale, e.title)}</h2>
                  <p className="text-sm text-muted-foreground">
                    {locText(locale, e.place)} · {new Date(e.at).toLocaleString(localeTag(locale))}
                  </p>
                </div>
                <Badge tone={e.inviteOnly ? "gold" : "wool"}>
                  {e.inviteOnly ? t("events.inviteOnly") : t("events.open")}
                </Badge>
              </div>
              <p className="mt-2 text-sm text-pretty">{locText(locale, e.note)}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {t("events.host")}: {hidden ? "—" : e.host}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant={going ? "secondary" : "outline"}
                  disabled={going}
                  onClick={() => rsvp(e.id)}
                >
                  {going ? t("events.rsvped") : t("events.rsvp")}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => downloadIcs(e)}>
                  {t("events.calendar")}
                </Button>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
