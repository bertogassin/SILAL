import { useEffect, type ReactNode } from "react";
import { localeTag } from "@/lib/si/i18n";
import { useSi } from "@/lib/si/store";
import { setSoundsEnabled } from "@/lib/si/sounds";

export function SiProvider({ children }: { children: ReactNode }) {
  const theme = useSi((s) => s.theme);
  const locale = useSi((s) => s.locale);
  const sounds = useSi((s) => s.sounds);

  useEffect(() => {
    const apply = () => {
      const st = useSi.getState();
      document.documentElement.dataset.theme = st.theme;
      document.documentElement.lang = localeTag(st.locale);
      setSoundsEnabled(st.sounds);
      useSi.setState({ hydrated: true });
    };
    try {
      void Promise.resolve(useSi.persist.rehydrate()).finally(apply);
    } catch {
      apply();
    }
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.lang = localeTag(locale);
    setSoundsEnabled(sounds);
  }, [theme, locale, sounds]);

  return <>{children}</>;
}
