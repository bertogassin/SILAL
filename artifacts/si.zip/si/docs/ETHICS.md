# Ethics

si helps people recognize their people, keep the kin, agree, and hold value with care. It does not judge, brand, or avenge.

## What si is not

- Not a court and not a state
- Not a social credit system
- Not a blacklist of “bad people”
- Not a blood-feud machine
- Not a pyramid
- Not a hidden mint
- Not a seller of the kinship graph

Adat and sharia, when they appear in later educational layers, are custom and personal choice. They do not replace the law of the country of residence.

## Consent

A living person appears in someone else’s published tree only with their consent. Ancestors follow family rules. Minors have no wallet and no public map.

## Women’s safety contour

Hidden profile, a family contact, and a private block. The block is not a public shaming list.

## Money

SILAL is a community utility token. It cannot buy the status of a good person. The application cannot seize another person’s coins. Referral is one level, paid from a pre-allocated fund, with a cap.

## Forbidden modules (never)

Quiet bans without cause, a unified reputation score, automatic moral punishment by contract, hidden geolocation, doxxing, publishing living minors on-chain, multi-level referral.
